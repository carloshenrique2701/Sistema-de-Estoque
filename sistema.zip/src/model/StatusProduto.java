package model;

public enum StatusProduto {
	EM_FALTA,
	BAIXO_ESTOQUE,
	A_VENDA, 
	ESTOQUE_COMPLETO
}
