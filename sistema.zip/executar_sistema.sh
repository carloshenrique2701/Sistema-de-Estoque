#!/bin/bash

# Script para executar o Sistema de Controle de Estoque com Login
# Autor: Sistema de Controle de Estoque
# Data: $(date)

echo "=========================================="
echo "  Sistema de Controle de Estoque"
echo "=========================================="
echo ""

# Verificar se o arquivo JAR do MySQL existe
if [ ! -f "mysql-connector-java.jar" ]; then
    echo "❌ Erro: Arquivo mysql-connector-java.jar não encontrado!"
    echo "📁 Copiando o driver MySQL do sistema..."
    cp /usr/share/java/mysql-connector-j-9.3.0.jar mysql-connector-java.jar
    if [ $? -eq 0 ]; then
        echo "✅ Driver MySQL copiado com sucesso!"
    else
        echo "❌ Erro ao copiar o driver MySQL!"
        echo "💡 Instale o MySQL Connector: sudo apt install mysql-connector-java"
        exit 1
    fi
fi

# Verificar se o diretório bin existe
if [ ! -d "bin" ]; then
    echo "📁 Compilando o projeto..."
    mkdir -p bin
    javac -cp ".:mysql-connector-java.jar" -d bin src/model/*.java src/controller/*.java src/view/*.java
    if [ $? -eq 0 ]; then
        echo "✅ Projeto compilado com sucesso!"
    else
        echo "❌ Erro na compilação!"
        exit 1
    fi
fi

echo "🚀 Iniciando o sistema..."
echo ""
echo "📋 Credenciais de teste:"
echo "   Administrador: admin / admin123"
echo "   Gerente: gerente1 / gerente123"
echo ""

# Executar o sistema
java -cp ".:mysql-connector-java.jar:bin" view.LoginView

echo ""
echo "👋 Sistema encerrado." 